<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use LucianoTonet\GroqLaravel\Facades\Groq;

class ChatbotController extends Controller
{
    public function analyze(Request $request)
    {
        $caseDetails = $request->input('case_details');

        // Initialize the Groq API instance
        $groq = new Groq('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');

        // Create a chat completion for case analysis
        $chatCompletion = $groq->chat()->completions()->create([
            'model' => 'llama3-8b-8192',
            'messages' => [
                [
                    'role' => 'user',
                    'content' => "Analyze the following case details and summarize it. Identify the relevant legal articles or sections that may apply:\n\n" . $caseDetails,
                ],
            ],
        ]);

        // Extract the summary and articles from the response
        $output = $chatCompletion['choices'][0]['message']['content'];
        // Process the output as needed
// dd($output);
        return view('chatbot', [
            'summary' => $output, // Adjust based on your desired structure
        ]);
    }
}
