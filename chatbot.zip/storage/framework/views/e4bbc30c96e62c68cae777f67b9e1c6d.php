<?php $__env->startSection('content'); ?>
<div class="container mt-5">
<div id="output" class="mt-5">
    hy

    <?php if(isset($summary) && isset($articles)): ?>
        <h3>Case Summary:</h3>
        <p><?php echo e($summary); ?></p>

        <h3>Relevant Articles/Sections:</h3>
        <ul>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($article); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chatbot\resources\views/chat.blade.php ENDPATH**/ ?>